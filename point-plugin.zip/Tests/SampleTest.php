<?php

namespace Plugin\Point\Tests;

class SampleTest extends \PHPUnit_Framework_TestCase
{
    public function testSample()
    {
        $this->assertTrue(true);
    }
}
